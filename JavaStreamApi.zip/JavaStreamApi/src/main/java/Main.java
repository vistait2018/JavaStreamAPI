import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Main {
   static List<Employee> employees = new ArrayList<>();

   static {
       employees.add( new Employee(UUID.randomUUID().toString(),"Babjide","Olawale",6000d, List.of("fan-club","github")));

       employees.add(new Employee(UUID.randomUUID().toString(),"Johnson","Majidun",3400d, List.of("press","wolve")));
       employees.add(new Employee(UUID.randomUUID().toString(),"Moraba","Olawale",2400d, List.of("fan-club","github")));
       employees.add(new Employee(UUID.randomUUID().toString(),"Monday","Bello",45450d, List.of("plan-club","github")));
       employees.add(new Employee(UUID.randomUUID().toString(),"Buraimo","Remilekun",89450d, List.of("hat-club","github")));
       employees.add(new Employee(UUID.randomUUID().toString(),"Tajudeen","Sule",900450d, List.of("Ball-club","github")));
   }
    public static void main(String[] args) {
        System.out.println("He Stream Api");
        //Stream.of
        //Stream.of(employees).forEach(employee -> System.out.println(employee +"\n") );

        //.stream

       // employees.stream().forEach(employee -> System.out.println(employee +"\n"));

       //map
//        employees.stream().map(employee ->  new Employee(
//                employee.getId(), employee.getFirstName(), employee.getLastName(), employee.getSalary() *10,
//                employee.getProjects()
//        )).forEach(employee -> System.out.println(employee+"\n"));

        //filter
//        employees.stream().filter(employee -> employee.getSalary()> 900000)
//                .forEach(employee -> System.out.println(employee+"\n"));

         //findFirst and OrElse
//        Employee firstEmployee = employees.stream().filter(employee -> employee.getSalary() > 900000).findFirst().orElse(null);
//        System.out.println(firstEmployee);


//        //findfirst orElseThrow
//        Employee firstEmployee = employees.stream().filter(employee -> employee.getSalary() > 100000000).findFirst().orElseThrow(()->new RuntimeException("An Error occured"));
//        System.out.println(firstEmployee);

        //flatMap
      // String projects = employees.stream().map(employee -> employee.getProjects())

               // .flatMap(strings -> strings.stream())

                //.collect(Collectors.joining(","));

        //System.out.println(projects);

//        //shortCircuit
//        employees.stream().skip(2).limit(3).forEach(employee -> System.out.println(employee));

        //finite Data
      //  Stream.generate(Math::random)
//                .limit(5)
//                .map(value->value*10 )
//                .forEach(value-> System.out.println(value));

//      sorting
//        List<Employee> sorted = employees.stream().sorted((e1,e2)-> e1.getFirstName().compareToIgnoreCase(e2.getFirstName()) )
//                .collect(Collectors.toList());
//        System.out.println(sorted);


        //min or max

       // employees.stream().max(Comparator.comparing(Employee::getSalary)).orElseThrow( NoSuchElementException::new);


        //reduce for addition
        Double totalSalary =employees.stream().map(employee -> employee.getSalary()).reduce(0.0,Double::sum);
        System.out.println(totalSalary);

    }
}
